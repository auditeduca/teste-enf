/**
 * NurseMetrics Engine — KPIs, OKRs, Incidentes
 * localStorage + Nurse-PaLM integration
 */
(function () {
  'use strict';
  const KPI_KEY = 'nis_nursemetrics_kpis';
  const OKR_KEY = 'nis_nursemetrics_okrs';
  const INC_KEY = 'nis_nursemetrics_incidents';

  const KPI_CAT_LABELS = { care_quality: 'Qualidade', patient_safety: 'Segurança', productivity: 'Produtividade', satisfaction: 'Satisfação', financial: 'Financeiro', operational: 'Operacional' };
  const STATUS_COLORS = { on_track: '#27ae60', at_risk: '#f39c12', off_track: '#e74c3c', achieved: '#2980b9' };
  const STATUS_LABELS = { on_track: 'No verde', at_risk: 'Em risco', off_track: 'Atrasado', achieved: 'Atingido' };
  const SEV_COLORS = { low: '#27ae60', moderate: '#f39c12', high: '#e74c3c', sentinel: '#8e44ad' };
  const SEV_LABELS = { low: 'Baixa', moderate: 'Moderada', high: 'Alta', sentinel: 'Sentinela' };
  const INC_TYPE_LABELS = { medication_error: 'Erro de Medicação', patient_fall: 'Queda', equipment_failure: 'Falha de Equipamento', documentation_error: 'Erro de Documentação', other: 'Outro' };
  const INC_STATUS_LABELS = { reported: 'Reportado', investigating: 'Investigando', resolved: 'Resolvido' };

  function getKpis() { try { return JSON.parse(localStorage.getItem(KPI_KEY) || '[]'); } catch { return []; } }
  function saveKpis(k) { localStorage.setItem(KPI_KEY, JSON.stringify(k)); }
  function getOkrs() { try { return JSON.parse(localStorage.getItem(OKR_KEY) || '[]'); } catch { return []; } }
  function saveOkrs(o) { localStorage.setItem(OKR_KEY, JSON.stringify(o)); }
  function getIncidents() { try { return JSON.parse(localStorage.getItem(INC_KEY) || '[]'); } catch { return []; } }
  function saveIncidents(i) { localStorage.setItem(INC_KEY, JSON.stringify(i)); }

  function calcKpiStatus(current, target, previous) {
    if (current === target) return 'achieved';
    const progress = target !== 0 ? Math.min(100, Math.round((current / target) * 100)) : 0;
    if (progress >= 75) return 'on_track';
    if (progress >= 50) return 'at_risk';
    return 'off_track';
  }

  function calcTrend(current, previous) {
    if (previous === 0 || previous === undefined) return 'flat';
    return current > previous ? 'up' : current < previous ? 'down' : 'flat';
  }

  // ===== KPI =====
  function addKpi() {
    const name = val('kpiName');
    if (!name) { alert('Preencha o nome.'); return; }
    const current = float('kpiCurrent');
    const target = float('kpiTarget');
    const previous = float('kpiPrevious');
    const status = calcKpiStatus(current, target, previous);
    const kpi = {
      id: Date.now().toString(), name,
      category: val('kpiCategory'),
      unit: val('kpiUnit'),
      currentValue: current, target, previousValue: previous,
      sector: val('kpiSector'),
      period: val('kpiPeriod'),
      status,
      createdAt: new Date().toISOString(),
    };
    const kpis = getKpis();
    kpis.unshift(kpi);
    saveKpis(kpis);
    ['kpiName','kpiUnit','kpiCurrent','kpiTarget','kpiPrevious','kpiSector','kpiPeriod'].forEach(clearInput);
    renderKpis();
    renderStats();
  }

  function renderKpis() {
    const el = document.getElementById('kpiList');
    if (!el) return;
    const kpis = getKpis();
    if (!kpis.length) { el.innerHTML = '<p class="field-hint">Nenhum KPI.</p>'; return; }
    el.innerHTML = kpis.map(k => {
      const progress = k.target !== 0 ? Math.min(100, Math.round((k.currentValue / k.target) * 100)) : 0;
      const trend = calcTrend(k.currentValue, k.previousValue);
      const trendIcon = trend === 'up' ? '↑' : trend === 'down' ? '↓' : '→';
      const trendColor = trend === 'up' ? '#27ae60' : trend === 'down' ? '#e74c3c' : 'var(--c-text-muted)';
      return `<div style="padding:0.75rem;border:1px solid var(--c-border);border-radius:0.5rem;margin-bottom:0.75rem">
        <div style="display:flex;justify-content:space-between;align-items:start">
          <div style="flex:1">
            <p style="font-weight:600">${k.name}</p>
            <p style="font-size:0.85rem;color:var(--c-text-muted)">${KPI_CAT_LABELS[k.category]} · ${k.sector || '—'} · ${k.period || '—'}</p>
            <div style="display:flex;gap:1rem;margin-top:0.5rem;align-items:center">
              <span style="font-size:1.2rem;font-weight:700">${k.currentValue}${k.unit ? ' ' + k.unit : ''}</span>
              <span style="font-size:0.85rem;color:var(--c-text-muted)">Meta: ${k.target}${k.unit ? ' ' + k.unit : ''}</span>
              <span style="font-size:0.9rem;color:${trendColor};font-weight:600">${trendIcon} ${k.previousValue !== undefined ? k.previousValue + (k.unit ? ' ' + k.unit : '') : '—'}</span>
            </div>
            <div style="margin-top:0.5rem;background:var(--c-surface);border-radius:0.5rem;height:8px;overflow:hidden">
              <div style="height:100%;background:${STATUS_COLORS[k.status]};width:${progress}%"></div>
            </div>
            <p style="font-size:0.8rem;color:var(--c-text-muted);margin-top:0.25rem">${progress}% da meta</p>
          </div>
          <div style="display:flex;flex-direction:column;gap:0.25rem;align-items:flex-end">
            <span style="background:${STATUS_COLORS[k.status]};color:#fff;padding:0.25rem 0.75rem;border-radius:1rem;font-size:0.75rem;font-weight:600">${STATUS_LABELS[k.status]}</span>
            <button class="btn-icon" style="font-size:0.8rem;padding:0.25rem 0.5rem" onclick="window.NurseMetrics.delKpi('${k.id}')">Excluir</button>
          </div>
        </div>
      </div>`;
    }).join('');
  }

  function delKpi(id) { saveKpis(getKpis().filter(k => k.id !== id)); renderKpis(); renderStats(); }

  // ===== OKR =====
  function addOkr() {
    const obj = val('okrObjective');
    if (!obj) { alert('Preencha o objetivo.'); return; }
    const krText = val('okrKeyResults');
    const keyResults = krText.split('\n').filter(l => l.trim()).map(l => ({ description: l.trim(), progress: 0 }));
    const okr = {
      id: Date.now().toString(), objective: obj,
      sector: val('okrSector'),
      year: num('okrYear'),
      quarter: val('okrQuarter'),
      responsible: val('okrResponsible'),
      keyResults,
      overallProgress: 0,
      status: 'active',
      createdAt: new Date().toISOString(),
    };
    const okrs = getOkrs();
    okrs.unshift(okr);
    saveOkrs(okrs);
    ['okrObjective','okrSector','okrResponsible','okrKeyResults'].forEach(clearInput);
    renderOkrs();
    renderStats();
  }

  function renderOkrs() {
    const el = document.getElementById('okrList');
    if (!el) return;
    const okrs = getOkrs();
    if (!okrs.length) { el.innerHTML = '<p class="field-hint">Nenhum OKR.</p>'; return; }
    el.innerHTML = okrs.map(o => `
      <div style="padding:0.75rem;border:1px solid var(--c-border);border-radius:0.5rem;margin-bottom:0.75rem">
        <div style="display:flex;justify-content:space-between;align-items:start">
          <div style="flex:1">
            <p style="font-weight:600">${o.objective}</p>
            <p style="font-size:0.85rem;color:var(--c-text-muted)">${o.sector || '—'} · ${o.year} ${o.quarter} · Resp: ${o.responsible || '—'}</p>
            <div style="margin-top:0.5rem;background:var(--c-surface);border-radius:0.5rem;height:10px;overflow:hidden">
              <div style="height:100%;background:var(--c-primary);width:${o.overallProgress || 0}%"></div>
            </div>
            <p style="font-size:0.8rem;color:var(--c-text-muted);margin-top:0.25rem">${o.overallProgress || 0}% · ${o.keyResults?.length || 0} key results</p>
            ${o.keyResults?.length ? `<details style="margin-top:0.5rem"><summary style="font-size:0.85rem;cursor:pointer;color:var(--c-primary)">Ver Key Results</summary><ul style="padding-left:1.5rem;margin-top:0.5rem;line-height:1.8;font-size:0.9rem">${o.keyResults.map(kr => `<li>${kr.description} <span style="color:var(--c-text-muted)">(${kr.progress}%)</span></li>`).join('')}</ul></details>` : ''}
          </div>
          <div style="display:flex;flex-direction:column;gap:0.25rem;align-items:flex-end">
            <span class="tool-category-badge" style="font-size:0.75rem">${o.status === 'active' ? 'Ativo' : o.status === 'completed' ? 'Concluído' : 'Pausado'}</span>
            <button class="btn-icon" style="font-size:0.8rem;padding:0.25rem 0.5rem" onclick="window.NurseMetrics.delOkr('${o.id}')">Excluir</button>
          </div>
        </div>
      </div>
    `).join('');
  }

  function delOkr(id) { saveOkrs(getOkrs().filter(o => o.id !== id)); renderOkrs(); renderStats(); }

  // ===== Incident =====
  function addIncident() {
    const title = val('incTitle');
    if (!title) { alert('Preencha o título.'); return; }
    const inc = {
      id: Date.now().toString(), title,
      type: val('incType'),
      severity: val('incSeverity'),
      sector: val('incSector'),
      date: val('incDate'),
      description: val('incDesc'),
      actionsTaken: val('incActions'),
      status: 'reported',
      responsible: '',
      createdAt: new Date().toISOString(),
    };
    const incs = getIncidents();
    incs.unshift(inc);
    saveIncidents(incs);
    ['incTitle','incSector','incDate','incDesc','incActions'].forEach(clearInput);
    renderIncidents();
    renderStats();
  }

  function renderIncidents() {
    const el = document.getElementById('incidentList');
    if (!el) return;
    const incs = getIncidents();
    if (!incs.length) { el.innerHTML = '<p class="field-hint">Nenhum incidente.</p>'; return; }
    el.innerHTML = incs.map(i => `
      <div style="padding:0.75rem;border:1px solid var(--c-border);border-left:4px solid ${SEV_COLORS[i.severity]};border-radius:0.5rem;margin-bottom:0.75rem">
        <div style="display:flex;justify-content:space-between;align-items:start">
          <div>
            <p style="font-weight:600">${i.title}</p>
            <p style="font-size:0.85rem;color:var(--c-text-muted)">${INC_TYPE_LABELS[i.type]} · ${i.sector || '—'} · ${i.date ? new Date(i.date).toLocaleDateString('pt-BR') : '—'}</p>
            ${i.description ? `<p style="font-size:0.9rem;margin-top:0.25rem">${i.description}</p>` : ''}
            ${i.actionsTaken ? `<p style="font-size:0.85rem;margin-top:0.25rem"><strong>Ações:</strong> ${i.actionsTaken}</p>` : ''}
          </div>
          <div style="display:flex;flex-direction:column;gap:0.25rem;align-items:flex-end">
            <span style="background:${SEV_COLORS[i.severity]};color:#fff;padding:0.25rem 0.75rem;border-radius:1rem;font-size:0.75rem;font-weight:600">${SEV_LABELS[i.severity]}</span>
            <select onchange="window.NurseMetrics.updateIncidentStatus('${i.id}', this.value)" style="font-size:0.8rem;padding:0.25rem;border-radius:0.4rem;border:1px solid var(--c-border)">
              <option value="reported" ${i.status==='reported'?'selected':''}>Reportado</option>
              <option value="investigating" ${i.status==='investigating'?'selected':''}>Investigando</option>
              <option value="resolved" ${i.status==='resolved'?'selected':''}>Resolvido</option>
            </select>
            <button class="btn-icon" style="font-size:0.8rem;padding:0.25rem 0.5rem" onclick="window.NurseMetrics.delIncident('${i.id}')">Excluir</button>
          </div>
        </div>
      </div>
    `).join('');
  }

  function updateIncidentStatus(id, status) {
    const incs = getIncidents();
    const idx = incs.findIndex(i => i.id === id);
    if (idx >= 0) { incs[idx].status = status; saveIncidents(incs); renderIncidents(); renderStats(); }
  }

  function delIncident(id) { saveIncidents(getIncidents().filter(i => i.id !== id)); renderIncidents(); renderStats(); }

  // ===== Stats =====
  function renderStats() {
    const kpis = getKpis();
    const okrs = getOkrs();
    const incs = getIncidents();
    setText('nmStatOnTrack', kpis.filter(k => k.status === 'on_track' || k.status === 'achieved').length);
    setText('nmStatAtRisk', kpis.filter(k => k.status === 'at_risk' || k.status === 'off_track').length);
    setText('nmStatOKRs', okrs.filter(o => o.status === 'active').length);
    setText('nmStatIncidents', incs.filter(i => i.status !== 'resolved').length);
  }

  // ===== Nurse-PaLM Cognitive Analysis =====
  function runCognitive() {
    const kpis = getKpis();
    const okrs = getOkrs();
    const incs = getIncidents();
    const el = document.getElementById('nmCognitiveResult');
    if (!el) return;
    if (!kpis.length && !okrs.length && !incs.length) { el.innerHTML = '<p class="field-hint">Registre dados primeiro.</p>'; return; }

    // Nurse-PaLM cognitive engine
    let cognitiveInsight = '';
    if (window.NursePaLM && window.CognitiveUI) {
      try {
        const avgProgress = kpis.length ? kpis.reduce((s, k) => s + Math.min(100, (k.currentValue / k.target) * 100), 0) / kpis.length : 0;
        const sentinelCount = incs.filter(i => i.severity === 'sentinel').length;
        // Build observations from KPI performance
        const observations = [
          { type: 'heartRate', value: 72 + (100 - avgProgress) * 0.5 },
          { type: 'systolicBP', value: 120 - sentinelCount * 5 },
          { type: 'spO2', value: 98 - Math.min(5, sentinelCount * 2) },
          { type: 'respiratoryRate', value: 16 + Math.round((100 - avgProgress) / 10) },
        ];
        const attention = window.NursePaLM.evaluateAttention(observations);
        const alertLevel = attention.alert ? '🔴 CRÍTICO' : attention.filtered.length > 2 ? '🟡 ATENÇÃO' : '🟢 NORMAL';
        cognitiveInsight = `<div style="padding:0.75rem;background:#fff;border-radius:0.5rem;border-left:3px solid var(--c-primary);margin-top:0.5rem">
          <p style="font-size:0.9rem;font-weight:600">🧠 Nurse-PaLM V9 — Análise Cognitiva:</p>
          <p style="font-size:0.85rem;margin-top:0.25rem">Nível de alerta: <strong>${alertLevel}</strong></p>
          <p style="font-size:0.85rem">Sinais em atenção: ${attention.filtered.length} de ${attention.ranked.length}</p>
          <p style="font-size:0.85rem">Performance média: ${avgProgress.toFixed(0)}% · Incidentes sentinelas: ${sentinelCount}</p>
        </div>`;
      } catch (e) { console.warn('[NurseMetrics] Nurse-PaLM error:', e); }
    }

    // Heuristic analysis
    const offTrack = kpis.filter(k => k.status === 'off_track');
    const sentinels = incs.filter(i => i.severity === 'sentinel' && i.status !== 'resolved');
    const incByType = {};
    incs.forEach(i => { incByType[i.type] = (incByType[i.type] || 0) + 1; });
    const topIncType = Object.entries(incByType).sort((a, b) => b[1] - a[1])[0];
    const activeOkrs = okrs.filter(o => o.status === 'active');
    const avgOkrProgress = activeOkrs.length ? activeOkrs.reduce((s, o) => s + (o.overallProgress || 0), 0) / activeOkrs.length : 0;

    el.innerHTML = `
      <div style="padding:1rem;background:var(--c-surface);border-radius:0.5rem;border:1px solid var(--c-border)">
        <h3 style="font-size:1rem;font-weight:700;margin-bottom:0.5rem">📊 Análise de Desempenho</h3>
        <ul style="padding-left:1.5rem;line-height:2;font-size:0.9rem">
          <li><strong>${kpis.length}</strong> KPIs · ${offTrack.length} atrasados · ${kpis.filter(k => k.status === 'achieved').length} atingidos</li>
          <li><strong>${activeOkrs.length}</strong> OKRs ativos · Progresso médio: <strong>${avgOkrProgress.toFixed(0)}%</strong></li>
          <li><strong>${incs.length}</strong> incidentes · ${sentinels.length} sentinelas não resolvidas</li>
          <li>Tipo de incidente mais frequente: <strong>${topIncType ? INC_TYPE_LABELS[topIncType[0]] : '—'}</strong> (${topIncType ? topIncType[1] : 0})</li>
        </ul>
        ${cognitiveInsight}
        <div style="margin-top:0.75rem;padding:0.75rem;background:#fff;border-radius:0.5rem;border-left:3px solid var(--c-primary)">
          <p style="font-size:0.9rem;font-weight:600">⚡ Recomendações:</p>
          <ul style="padding-left:1.5rem;line-height:1.8;font-size:0.85rem;margin-top:0.25rem">
            ${sentinels.length > 0 ? '<li style="color:#e74c3c"><strong>URGENTE:</strong> Investigar incidentes sentinelas não resolvidos</li>' : ''}
            ${offTrack.length > 0 ? `<li><strong>${offTrack.length} KPIs</strong> precisam de plano de recuperação</li>` : ''}
            ${avgOkrProgress < 50 ? '<li>OKRs com progresso abaixo de 50% — revisar key results</li>' : ''}
            <li>Manter cadência de revisão semanal de indicadores</li>
          </ul>
        </div>
      </div>
    `;
  }

  // Utils
  function val(id) { return document.getElementById(id)?.value?.trim() || ''; }
  function num(id) { return parseInt(document.getElementById(id)?.value) || 0; }
  function float(id) { return parseFloat(document.getElementById(id)?.value) || 0; }
  function setText(id, v) { const el = document.getElementById(id); if (el) el.textContent = v; }
  function clearInput(id) { const el = document.getElementById(id); if (el) el.value = ''; }

  function init() {
    document.getElementById('addKpiBtn')?.addEventListener('click', addKpi);
    document.getElementById('addOkrBtn')?.addEventListener('click', addOkr);
    document.getElementById('addIncidentBtn')?.addEventListener('click', addIncident);
    document.getElementById('nmCognitiveBtn')?.addEventListener('click', runCognitive);
    renderKpis();
    renderOkrs();
    renderIncidents();
    renderStats();
  }

  window.NurseMetrics = { delKpi, delOkr, delIncident, updateIncidentStatus, init };
  if (document.readyState !== 'loading') init();
  else document.addEventListener('DOMContentLoaded', init);
})();
